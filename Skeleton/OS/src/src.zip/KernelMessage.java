public class KernelMessage {
}
